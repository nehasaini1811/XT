/**
 * Ex-3: Appoint Vendor  = ( give me  a ‘name’ to this pattern )
You are given a sample function which executes service logic. When we call that function,
(a) sould log before & after 
(b) should calculate total time it took to execute
(c) should catch error if any thrown

But we sould not implement these concerns in service function. Must be individual functions and compose them to achieve our goal.


 */

function serviceFunc() {
    let promise = new Promise((resolve, reject) => {
        console.log("service logic processing");
        setTimeout(() => {
            let responseStr = "service logic executed";
            resolve(responseStr)
        }, 3000);
    });
    return promise;
}
// class Vendor {
function Vendor() {
    this.executionStartTime = new Date();
    // this.executionEndTime = new Date();
    console.log(`Vendor execution start time logged as: ${this.executionStartTime}`);
    let servicePromise = serviceFunc();
    servicePromise.then(
        result => {
            console.log(result)
            this.executionEndTime = new Date();
            console.log(`Vendor execution completed time logged as: ${this.executionEndTime}`);
            console.log(`Vendor took ${(this.executionEndTime - this.executionStartTime)/1000} seconds to execute`);
        },
        error => {
            console.log(error)
            this.executionEndTime = new Date();
            console.log(`Vendor execution completed time logged as: ${this.executionEndTime}`);
            console.log(`Vendor took ${(this.executionEndTime - this.executionStartTime)/1000} seconds to execute`);
        }
    )
}
// }
const v1 = new Vendor();