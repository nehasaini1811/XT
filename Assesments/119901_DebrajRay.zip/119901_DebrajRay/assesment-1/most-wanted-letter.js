/**
 * Ex-2: The Most Wanted Letter
You are given a text, which contains different english letters and punctuation symbols.
You should find the most frequent letter in the text.
The letter returned must be in lower case.
While checking for the most wanted letter, casing does not matter,
so for the purpose of your search, "A" == "a".
Make sure you do not count punctuation symbols, digits and whitespaces, only letters.
If you have two or more letters with the same frequency,
then return the letter which comes first in the latin alphabet.
For example -- "one" contains "o", "n", "e" only once for each, thus we choose "e".

Input: A text for analysis as a string.
Output: The most frequent letter in lower case as a string.
Example:
mostWanted("Hello World!") == "l"
mostWanted("How do you do?") == "o"
mostWanted("One") == "e"
mostWanted("Oops!") == "o"
mostWanted("AAaooo!!!!") == "a"
mostWanted("abe") == "a"

 */

 function mostWanted(str) {
    console.log('Input String: ' , str);
    let punctuationless = str.replace(/[.,\/#!$%\^&?'"\*;:{}=\-_`~()]/g,""),
        withoutSpaceString = punctuationless.replace(/\s/g,""),
        strArrSorted = withoutSpaceString.toLowerCase().split('').sort(),
        i=0,maxCount=0, strArrLength = strArrSorted.length, charCountObj = {};
    // console.log(strArrSorted);
    // var s = 'A'; console.log(s.charCodeAt(0));
    // console.log(String.fromCharCode(122)) //z
    for(i=0; i < strArrLength; i++) {
        if(!charCountObj.hasOwnProperty(strArrSorted[i])) {
            charCountObj[strArrSorted[i]] = (withoutSpaceString.match(new RegExp(strArrSorted[i], "g"))||[]).length;
        }
    }
    console.log(charCountObj);
    let charCountObjKeys = Object.keys(charCountObj),
        charCountObjValues = Object.values(charCountObj);
    maxCount = Math.max(...charCountObjValues);
    //Below line will always return the 1st index of the matched element and as elements in object are already sorted alphabetically so draw case will be for sure resolved with latin alphabetical order
    let maxCountIndex = charCountObjValues.indexOf(maxCount);
        return charCountObjKeys[maxCountIndex];
 }
 console.log('The Most Wanted Letter: ' , mostWanted("Hello World!"))// == "l"
 console.log('The Most Wanted Letter: ' , mostWanted("How do you do?"))// == "o"
 console.log('The Most Wanted Letter: ' , mostWanted("One"))// == "e"
 console.log('The Most Wanted Letter: ' , mostWanted("Oops!"))// == "o"
 console.log('The Most Wanted Letter: ' , mostWanted("AAaooo!!!!"))// == "a"
 console.log('The Most Wanted Letter: ' , mostWanted("abe"))// == "a"