/**
 * Ex-4: Music Player  = ( give me  a ‘name’ to this pattern )

Song => {title :string , duration: number}

Create list of songs, and getNextSong() function which can return next song based user sceduling strategy

Strategies
•	SDNS => shortest duration next song
•	LDNS => longest duration next song
•	FINS => first in next song

Condition: getNextSong() must be polymophic, strategy function must be parameter 

 */

class Musicplayer {
    constructor(songs=[]) {
        this.songs = songs;
    }
    getNextSong(strategy) { //polymorphic function with variation in function arguments
        if(this.songs.length > 0){
            let nextSongIndex = 0,
                songOrderedList = this.songs;
            if(strategy === 'SDNS') { //ascending order songs duration
                songOrderedList = this.songs.sort((a, b) => (a['duration'] > b['duration'] ? 1 : -1));
            }
            else if(strategy === 'LDNS') { //descending order songs duration
                songOrderedList = this.songs.sort((a, b) => (a['duration'] > b['duration'] ? -1 : 1));
            }
            else {//if(strategy === 'FINS') { //simply point the next index in the last available song list
                nextSongIndex += 1;
            }
            return songOrderedList[nextSongIndex];
        }
    }
    listAllSongs() {
        console.log('All Songs list:-', this.songs);
    }
}
let songList = [
    {title :'Dhadak - Title song' , duration: 196},
    {title :'chak de india' , duration: 283},
    {title :'ban ja rani - tumhari sulu' , duration: 226},
    {title :'Breathless - Mahadevan' , duration: 181},
    {title :'suno-gaur-se-duniya-walo' , duration: 270},
    {title :'Zingaat Song - Dhadak' , duration: 226}
];
const mp = new Musicplayer(songList);
mp.listAllSongs();
console.log('shortest duration next song :-', mp.getNextSong('SDNS'));
console.log('longest duration next song :-', mp.getNextSong('LDNS'));
console.log('first in next song :-', mp.getNextSong('FINS'));