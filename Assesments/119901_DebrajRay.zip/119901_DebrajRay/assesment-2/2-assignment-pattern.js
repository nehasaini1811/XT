/**
Behavioral Design Pattern/ Observer/Listener pattern

Below should be the modules:-
1) Door Module -> Event Emitter
2) Light Module
3) AC Module
4) Projector Module

All listeners should have 2 methods:-
    -> start
    -> stop

    when creating the door, can't create listeners
    listeners have to be created later
**/

class Door {
    constructor(floorNum, doorNum) {
        this.floorNum = floorNum;
        this.doorNum = doorNum;
        this.type = 'close'; //open | close
        console.log("Door instantiated!!");
    }
    open(...listenerObjs) {
        this.type = 'open';
        console.log("Door Opened! for door number# " + this.doorNum + ' at ' + this.floorNum + ' floor.');
        listenerObjs.map( objIndividual => objIndividual.start(this.floorNum, this.doorNum));
        // listenerObj.start();
    }
    close(...listenerObjs) {
        this.type = 'close';
        console.log("Door Closed! for door number# " + this.doorNum + ' at ' + this.floorNum + ' floor.');
        listenerObjs.map( objIndividual => objIndividual.stop(this.floorNum, this.doorNum));
        // listenerObj.stop();
    }
}

class ListenerModules {
    constructor(listenerItem) {
        // super(floorNum, doorNum, type);
        this.listenerItem = listenerItem; //Light/AC/Projector
        this.status = false; //Default status False = OFF
        console.log(listenerItem + " instantiated!!");
        
    }
    start(floorNum, doorNum) {
        this.status = true;
        console.log(this.listenerItem + " Started/ON for door number# " + doorNum + ' at floor number# ' + floorNum);
    }
    stop(floorNum, doorNum) {
        this.status = false;
        console.log(this.listenerItem + " Stop/OFF for door number# " + doorNum + ' at floor number# ' + floorNum);
    }
}

//-------
// Init phase
//-------
const door1 = new Door(1, 3);
const light1 = new ListenerModules('Light');
const ac1 = new ListenerModules('AC');
const projector1 = new ListenerModules('Projector');

//-------
// Use phase
//-------
door1.open(light1, ac1, projector1);
door1.close(light1, ac1, projector1);

//-------
// Destroy phase
//-------